This project as been replaced by SMV_Data_Acquisition_and_Management.

This projected is no longer being mantained, because the system design was changed and we are replacing the arudino and android systems with the beaglebone black.