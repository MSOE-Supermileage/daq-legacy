package edu.smv.android;

import android.app.Application;

/**
 * Default Android Application
 * No methods have been overridden
 * @author tutkowskim
 *
 */
public class MSOE_Data_Display extends Application {
        
}